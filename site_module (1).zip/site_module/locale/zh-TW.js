/**
 * zh-TW locale package for specific site
 * The example format as below
 * The key must be as same as the field name in area_table in database 
 */

const tw = {  

    /**
     * example: 
     * AREA_NAME_IN_AREA_TABLE_OF_DATABASE: YOUR_CUSTOMIZED_LOCALE_NAME
    */

    WHOLE_SITE: '公共區域',
    TEST_FIELD: '測試場域',
    NTUH_YUNLIN_WARD_FIVE_B: '5B病房',
    NURSING_HOME: '護理之家'

}

export default tw