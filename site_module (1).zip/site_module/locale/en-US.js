/**
 * en-US locale package for specific site
 * The example format as below
 * The key must be as same as the field name in area_table in database 
 */

const en = {

    /**
     * example: 
     * AREA_NAME_IN_AREA_TABLE_OF_DATABASE: YOUR_CUSTOMIZED_LOCALE_NAME
    */

    WHOLE_SITE: 'public space',
    TEST_FIELD: 'test field',
    NTUH_YUNLIN_WARD_FIVE_B: 'ntuh yunlin ward 5b',
    NURSING_HOME: 'nursing home'

}

export default en