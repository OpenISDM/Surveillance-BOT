/**
 * Area modules for specific site.
 * Follow the steps below to create your area modules.
 * 
 * 1. Place your area map image in the folder named map located in /site_module/img.
 * 2. Import the area map image from the folder. The image name should include extension.
 * 3. Set the modules as the example below. 
 */

const siteConfig = {

    areaModules: {

    },

}

export default siteConfig